
#include "stdafx.h"
#include "MFC_TERM_APP.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
	srand((int)time(NULL));	
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_CREATE()
END_MESSAGE_MAP()



// CChildView �޽��� ó����

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);
	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	CBitmap packman;
	packman.LoadBitmap(IDB_PACK);
	BITMAP bmpinfo;
	packman.GetBitmap(&bmpinfo);
	CDC mem;
	mem.CreateCompatibleDC(&mem);
	mem.SelectObject(&packman);
	dc.StretchBlt((int)600-R_d.x, (int)R_d.y, 50,50, &mem, 0,0,400,400,SRCCOPY);


	for (C_circle& circle : Circles)
	{
		CRect rect;
		rect.left  = (int)(circle.Center.x - circle.Radius);
		rect.right = (int)(circle.Center.x + circle.Radius);
		rect.top   = (int)(circle.Center.y - circle.Radius);
		rect.bottom= (int)(circle.Center.y + circle.Radius);
		
		CBrush R_brush(RGB(rand() % 255, rand() % 255, rand() % 255));
		CBrush *OldBrush = dc.SelectObject(&R_brush);
		dc.Ellipse(rect);
		dc.SelectObject(OldBrush);
	}
	
	if (Circles.size() == 0)
	{
		KillTimer(2);
		KillTimer(1);
		CString tm;
		tm.Format(_T("%d��"), TimeInetval);
		dc.SetBkMode(TRANSPARENT);
		dc.DrawText(tm, CRect(0, 0, 50, 50), 0);
		AfxMessageBox(tm, MB_OK);
		AfxGetApp()->m_pMainWnd->PostMessage(WM_CLOSE);
	}
}
void CChildView::ReceiveData(int classes, int x, int y, int width, int height, int score)
{
	R_target.x = x;
	R_target.y = y;
		
	TRACE("\tCLASS %d  x:%d, y:%d, width:%d, height:%d\n", classes, x,y,width,height);
}

void CChildView::Wait(DWORD dwMillisecond)
{
	MSG msg;
	DWORD dwStart;
	dwStart = GetTickCount();

	while (GetTickCount() - dwStart < dwMillisecond)
	{
		while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
}

int CChildView::GetCollidingCircle(C_data box, float BoxRad)
{ 
	for (int i = 0; i < Circles.size(); i++)
	{
		auto& circle = Circles[i];

		float delta_x = 600.f-box.x - circle.Center.x;
		float delta_y = box.y - circle.Center.y;

		float RequiredDistance = BoxRad + circle.Radius;

		if (delta_x * delta_x + delta_y * delta_y 
			< RequiredDistance*RequiredDistance)
		{
			return i;
		}
	}
	return -1;
}

void CChildView::MakeCircle()
{
	int Xpos, Ypos;
	float radius;
	for (int i = 0; i < rand()%10+5; i++)
	{
		Xpos = rand() % 500 + 100;
		Ypos = rand() % 500 + 100;
		radius = rand() / (float)RAND_MAX * 30.f+20.f;
		Circles.push_back({ (CPoint(Xpos, Ypos)), radius });
	}
}

static inline float lerp(float a, float b, float k)
{
	return a + (b - a) * k;
}

void CChildView::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	CWnd::OnTimer(nIDEvent);
	if (nIDEvent == 1)
	{

		if (Dataready == TRUE)
		{
			Dataready = false;
		}

		for (auto& circle : Circles)
		{
			int xdel = rand() % 3 - 1;
			int ydel = rand() % 3 - 1;

			
			xdel *= rand() % 8;
			ydel *= rand() % 8;

			if ((circle.Center.x > 0) && (circle.Center.x < 600) && (circle.Center.y > 0) && (circle.Center.y<500))
			{
				circle.Center.x += xdel;
				circle.Center.y += ydel;
			}
			else
			{
				circle.Center.x = 300;
				circle.Center.y = 250;
			}
		}

		R_d.x = lerp(R_d.x, R_target.x, 0.0166f);
		R_d.y = lerp(R_d.y, R_target.y, 0.0166f); 

		int IdxCollide = GetCollidingCircle(R_d, 10.0f);
		if (IdxCollide != -1)
		{
			
			Circles.erase(Circles.begin() + IdxCollide);
		}

		Invalidate(true);
	}
	else
	{
		TimeInetval++;
	}
}


int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	TimeInetval = 0;
	SetTimer(1, 15, NULL);
	SetTimer(2, 1000, NULL);
	MakeCircle();
	return 0;
}

