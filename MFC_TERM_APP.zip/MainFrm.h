#pragma once
#include "ChildView.h"
#include <WinSock2.h>
#include <vector>
#include <atomic>

#pragma pack(push, 1)
struct YOLO_DETECTION_DATA
{
	int CLASS;
	int X;
	int Y;
	int WIDTH;
	int HEIGHT;
	float SCORE;
}; 
#pragma pack(pop)

class CMainFrame : public CFrameWnd
{
	
public:
	CMainFrame();
protected: 
	DECLARE_DYNAMIC(CMainFrame)

// Ư���Դϴ�.
public:

// �۾��Դϴ�.
public:

// �������Դϴ�.
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);

	void OnYoloRecv(std::vector<YOLO_DETECTION_DATA> LatestRecvData);

// �����Դϴ�.
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // ��Ʈ�� ������ ���Ե� ����Դϴ�.
	CToolBar          m_wndToolBar;
	CStatusBar        m_wndStatusBar;
	CChildView		  m_wndView;

	SOCKET sockRecv;
	SOCKADDR_IN addrRecv;

	std::atomic_bool bThreadExpire = false;

// ������ �޽��� �� �Լ�
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSetFocus(CWnd *pOldWnd);
	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnClose();
};


