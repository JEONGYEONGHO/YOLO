#pragma once
#include <vector>

struct C_circle
{
	CPoint Center;
	float  Radius;
};

// CChildView â
struct C_data
{
	float x = 0.0f;
	float y = 0.0f;
};

class CChildView : public CWnd
{
// �����Դϴ�.
public:
	CChildView();

// Ư���Դϴ�.
public:
	void ReceiveData(int classes, int x, int y, int width, int height, int score);
	void Wait(DWORD dwMillisecond);
	int GetCollidingCircle(C_data box, float BoxRad);
	BOOL Dataready;
	C_data R_d;
	C_data R_target;
	void MakeCircle();
	int TimeInetval;
public:

private:
	std::vector<C_circle> Circles;

// �������Դϴ�.
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs); 
// �����Դϴ�.
public:
	virtual ~CChildView();

	// ������ �޽��� �� �Լ�
protected:
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
//	afx_msg void OnClose();
};

